package connect;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Vector;

import javax.sql.DataSource;
import javax.swing.JOptionPane;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import entity.Student;

public class Connect_sql {
    private Connection conn = null;
    private PreparedStatement pstm = null;

    public Connect_sql() {
        try {
            Properties pro = new Properties();
            pro.load(Connect_sql.class.getClassLoader().getResourceAsStream("druid.properties"));
            DataSource ds = DruidDataSourceFactory.createDataSource(pro);
            conn = ds.getConnection();
            System.out.println("数据库连接成功");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "数据库连接失败", "警告", JOptionPane.WARNING_MESSAGE);
            System.exit(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void Close_db() {
        try {
            conn.close();
            pstm.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public Vector<Student> search_all() {
        Vector<Student> result = new Vector<Student>();
        try {
            String sql = "SELECT * FROM userinfo";
            pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            if (rs == null) {
                JOptionPane.showMessageDialog(null, "未找到任何学生数据", "警告", JOptionPane.WARNING_MESSAGE);
            }
            while (rs.next()) {
                Student student = getstudent(rs);
                result.add(student);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    // 添加数据
    public void increase_student(Object[] value) {
        try {
            String sql = "INSERT INTO userinfo VALUES(?,?,?)";
            pstm = conn.prepareStatement(sql);
            pstm.setLong(1, (Long.valueOf(String.valueOf(value[0]))));
            pstm.setString(2, value[1].toString());
            pstm.setLong(3, (Long.valueOf(String.valueOf(value[2]))));
            int affectedRows = pstm.executeUpdate(); // 在设置参数之后再执行更新
            if (affectedRows != 0) {
                JOptionPane.showMessageDialog(null, "更新成功", "提示", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "更新失败", "警告", JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {// 如果id重复在报错时会弹出一句包含PRIMARY KEY的报错语句
            String error = e.getMessage();
            if (error.contains("PRIMARY")) {
                JOptionPane.showMessageDialog(null, "id不可重复", "警告", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "id和密码必须为数字", "警告", JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 修改更新
    public void update_student(Object[] value) {
        try {
            String sql = "UPDATE userinfo SET id=?, `name` =?, `password`=? WHERE id=?";
            pstm = conn.prepareStatement(sql);
            pstm.setLong(1, (Long.valueOf(String.valueOf(value[0]))));
            pstm.setString(2, value[1].toString());
            pstm.setLong(3, (Long.valueOf(String.valueOf(value[2]))));
            pstm.setLong(4, (Long.valueOf(String.valueOf(value[3])))); // 设置 WHERE 条件的 id 参数
            int affectedRows = pstm.executeUpdate(); // 在设置参数之后执行更新
            if (affectedRows != 0) {
                JOptionPane.showMessageDialog(null, "更新成功", "提示", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "更新失败", "警告", JOptionPane.WARNING_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "id和密码必须为数字", "警告", JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 删除数据
    public void deleteUser(long value) {
        try {
            String sql = "DELETE FROM userinfo WHERE id=?";
            pstm = conn.prepareStatement(sql);
            pstm.setLong(1, value); // 设置参数
            int affectedRows = pstm.executeUpdate(); // 在设置参数之后执行更新
            if (affectedRows != 0) {
                JOptionPane.showMessageDialog(null, "删除成功", "提示", JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "当前操作不匹配", "警告", JOptionPane.WARNING_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 获取学生信息
    public Student getstudent(ResultSet rs) {
        try {
            Student person = new Student(
                    Integer.parseInt(rs.getString(1)),
                    rs.getString(2),
                    Integer.parseInt(rs.getString(3)));
            return person;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
