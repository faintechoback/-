import Mymodule.Myjframe;

public class experiment_main {
    public static void main(String[] args) {
        Myjframe myjframe = new Myjframe("学生管理系统");
        myjframe.setVisible(true); 
    }
}
