package function;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import connect.Connect_sql;
import entity.Student;

public class New_interface extends JDialog {
    List<JTextField> textFields = new ArrayList<>();
    List<JPanel> jPanels = new ArrayList<>();
    List<JLabel> jLabels = new ArrayList<>();
    JButton submit = new JButton("确认");

    String[] column = { "学生id", "学生姓名", "学生密码" };

    public New_interface(Student student, Connect_sql manager) {
        Object[] value = new Object[student==null? column.length:column.length+1];
        for (String text : column) {
            textFields.add(new JTextField());
            jLabels.add(new JLabel(text));
            jPanels.add(new JPanel());
        }
        if (student != null) {
            textFields.get(0).setText(String.valueOf(student.getId()));
            textFields.get(1).setText(student.getName());
            textFields.get(2).setText(String.valueOf(student.getPassword()));
        }

        for (int n = 0; n < column.length; n++) {
            jPanels.get(n).add(jLabels.get(n));
            jPanels.get(n).add(textFields.get(n));

            this.add(jPanels.get(n));
            jPanels.get(n).setLayout(null);

            jLabels.get(n).setBounds(10, 15, 60, 40);
            textFields.get(n).setBounds(110, 15, 180, 40);
        }
        submit.addActionListener((_) -> {
            try {
                if (Warning_input.Check_input(textFields)) {
                    int n = 0;
                    for (JTextField textField : textFields) {
                        value[n++] = textField.getText();
                    }
                    if (student != null) {
                        value[n]=student.getId();
                        manager.update_student(value);
                    } else {
                        manager.increase_student(value);
                    }
                    this.dispose();//前面如果成功会弹出对话框，对话框结束后自动关闭当前界面
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        });
        JPanel jPanel = new JPanel();
        this.add(jPanel);
        jPanel.add(submit);

        this.setLayout(new GridLayout(4, 1));
        this.setSize(new Dimension(350, 350));
        this.setTitle(student==null?"添加信息":"修改信息");
        setLocationRelativeTo(null);// 屏幕居中显示
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setResizable(false);// 设定大小不变
        this.setModal(true);
        this.setVisible(true);
    }
}
