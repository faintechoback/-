package function;

import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Warning_input {
    public static boolean Check_input(List<JTextField> lists) {
        for (JTextField jTextField : lists) {
            if (jTextField.getText().length() == 0) {
                JOptionPane.showMessageDialog(null, "请输入完整", "警告", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }
        return true;
    }

    public static boolean Check_select(int n) {//对应未选中单元格时，table.getSelectedRow())默认为-1
        if (n == -1) {
            JOptionPane.showMessageDialog(null, "未选中单元格", "警告", JOptionPane.WARNING_MESSAGE);
            return false;
        }else{
            return true;
        }
    }
}
