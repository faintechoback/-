package Mymodule;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Myjframe extends JFrame {
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();// 获取屏幕大小
    Mytool mytool;

    public Myjframe(String text) {
        this.setLayout(new BorderLayout());// 五方位布局
        this.setTitle(text);
        tablebuild();

        this.setSize(screenSize.width / 2, screenSize.height / 2);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void tablebuild() {
        Abstract_table abstract_table = new Abstract_table();
        JTable table = new JTable(abstract_table);
        table.setFillsViewportHeight(true);
        table.setAutoCreateRowSorter(true);
        JScrollPane scrollPane = new JScrollPane(table);
        this.add(scrollPane, BorderLayout.CENTER);
        this.revalidate();
        this.repaint();
        mytool = new Mytool(this, abstract_table, table);
    }
}
