package Mymodule;
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

import entity.Student;

public class Abstract_table extends AbstractTableModel{
    Vector<Student> customerVector = new Vector<Student>();
    private String[] columnNames = {"学生id","学生姓名","学生密码"};
    
    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return customerVector.size();
    }

    public Object getValueAt(int row, int col) {
        Student customer = customerVector.get(row);
        return customer.getCol(col);
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }
    public void updateData(Vector<Student> customerVector) {
        this.customerVector = customerVector;
        if (customerVector.size() == 0) {
            customerVector = new Vector<Student>();
        } else {
            fireTableRowsInserted(0, customerVector.size() - 1);
        }
    }
}
