package Mymodule;

import java.awt.BorderLayout;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;

import connect.Connect_sql;
import entity.Student;
import function.New_interface;
import function.Warning_input;

public class Mytool extends JPanel {
    JButton increase_button = new JButton("添加");
    JButton delete_button = new JButton("删除");
    JButton refresh_button = new JButton("刷新查看");
    JButton update_button = new JButton("修改");
    Vector<Student> allCustomer;
    Connect_sql manager = new Connect_sql();

    public Mytool(Myjframe myjframe, Abstract_table abstract_table, JTable table) {

        this.add(increase_button);
        this.add(delete_button);
        this.add(refresh_button);
        this.add(update_button);

        myjframe.add(this, BorderLayout.SOUTH);

        refresh_button.addActionListener((_) -> {
            allCustomer = manager.search_all();
            if (allCustomer.size() == 0) {
                JOptionPane.showMessageDialog(null, "当前不存在任何学生信息", "警告", JOptionPane.WARNING_MESSAGE);
            } else
                abstract_table.updateData(allCustomer);
        });
        increase_button.addActionListener((_) -> {
            new New_interface(null, manager);
        });
        update_button.addActionListener((_) -> {
            if (Warning_input.Check_select(table.getSelectedRow())) {
                new New_interface(allCustomer.get(table.getSelectedRow()), manager);
            }
        });
        delete_button.addActionListener((_) -> {
            if (Warning_input.Check_select(table.getSelectedRow())) {
                manager.deleteUser(allCustomer.get(table.getSelectedRow()).getId());
            }
        });
    }
}
