package entity;

public class Student {
    private String name;
    private long id;
    private long password;

    public Student( long id, String name,long password) {
        super();
        setId(id);
        setName(name);
        setPassword(password);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getPassword() {
        return password;
    }

    public void setPassword(long password) {
        this.password = password;
    }

    public Object getCol(int col) {
        switch (col) {
            case 0:
                return getId();
            case 1:
                return getName();
            case 2:
                return getPassword();
            default:
                return null;
        }
    }
}
